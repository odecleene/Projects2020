package structures;

public class RedBlackTree<T extends Comparable<T>> extends BinarySearchTree<T> {

  /** 
   * printTree.
   */
  public void printTree() {
    System.out.println("------------------------");
    if (root != null) {
      root.printSubtree(0);
    }
  }

  private boolean isRed(BstNode<T> node) {
    if (node == null) {
      return false;
    }
    return node.getColor() == BstNode.RED;
  }

  private boolean isBlack(BstNode<T> node) {
    if (node == null) {
      return true;
    }
    return node.getColor() == BstNode.BLACK;
  }

  private void rotateLeft(BstNode<T> node) {
    BstNode<T> r = node.getRight();
    node.setRight(r.getLeft());

    if (r.getLeft() != null) {
      r.getLeft().setParent(node);
    }
    r.setParent(node.getParent());
    if (node.getParent() == null) {
      this.root = r;
    } else {
      if (node.getParent().getLeft() == node) {
        node.getParent().setLeft(r);
      } else {
        node.getParent().setRight(r);
      }
    }

    r.setLeft(node);
    node.setParent(r);
  }

  private void rotateRight(BstNode<T> node) {
    BstNode<T> l = node.getLeft();
    node.setLeft(l.getRight());

    if (l.getRight() != null) {
      l.getRight().setParent(node);
    }
    l.setParent(node.getParent());
    if (node.getParent() == null) {
      this.root = l;
    } else {
      if (node == node.getParent().getRight()) {
        node.getParent().setRight(l);
      } else {
        node.getParent().setLeft(l);
      }
    }

    l.setRight(node);
    node.setParent(l);
  }

  // After inserting node, color it red and check BST property as followed,
  // 1. If node is root, make it black.
  // 2. if parent node is black, do nothing.
  // 3. if parent node is red, keep doing recursively for BST property by following,
  //   3.1 If uncle is RED, set color properly based on the instruction. 
  //       Then check for BST property on grandparent node.
  //   3.2 If uncle is black, and node is inside node, 
  //       do rotation on parent node to make a outside node case.
  //       If target node is the right child of parent node and 
  //       parent node is the left child of grandparent node, do left rotation.
  //       If target node is the left child of parent node and 
  //       parent node is the right child of grandparent node, do right rotation.
  //       After the rotation, checking for BST property on parent node.
  //   3.3 If uncle is black, and node is outside node, 
  //       make parent black and grandparent red,
  //       then do rotation on grandparent node.
  //       If target node is the right child of parent node and 
  //       parent node is the right child of grandparent node, do left rotation.
  //       If target node is the left child of parent node and 
  //       parent node is the left child of grandparent node, do right rotation.
  // HINT: It's helpful if you build getGrandparent and getUncle method first
  @Override
  public void add(T t) {
    if (t == null) {
      throw new NullPointerException();
    }
    //super.add(t);
    BstNode<T> node = new BstNode<T>(t, null, null);
    node.setColor(BstNode.RED);
    root = addToSubtree(root, node);
    printTree();
    check(node);
  }
    
  private void check(BstNode<T> node) {
    
    // if node is root
    if (node.getParent() == null) {
      node.setColor(BstNode.BLACK);
      printTree();
      return;
    }
    
    // if parent is black
    if (isBlack(node.getParent())) {
      return;
    }
    
    // else, the parent is red
    
    // if uncle is red
    if (isRed(node.getUncle())) {
      node.getParent().setColor(BstNode.BLACK);  // color parent black
      printTree();
      node.getUncle().setColor(BstNode.BLACK);  // color uncle black
      printTree();
      node.getGrandparent().setColor(BstNode.RED);  // color gparent red
      printTree();
      check(node.getGrandparent());  // check gparent node recursively
      return;
    }
    

    // if uncle is black, node is inside node
    if (!node.isOutside()) {
      BstNode<T> parent = node.getParent();
      if (parent.getLeft() == node) {
        rotateRight(parent);
      } else {
        rotateLeft(parent);
      }
      printTree();
      check(parent);
      return;
    }
    
    // if uncle is black, node is outside node
    if (node.isOutside()) {
      node.getParent().setColor(BstNode.BLACK);  // color parent black
      printTree();
      node.getGrandparent().setColor(BstNode.RED);  // color gparent red
      printTree();
      if (node.getGrandparent().getLeft() != null
          && node.getGrandparent().getLeft().getLeft() == node) {
        rotateRight(node.getGrandparent());
      } else {
        rotateLeft(node.getGrandparent());
      }
      printTree();
      return;
    }   
    
        
  }
}
