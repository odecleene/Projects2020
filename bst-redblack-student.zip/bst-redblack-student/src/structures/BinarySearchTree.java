package structures;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;

public class BinarySearchTree<T extends Comparable<T>> implements BstInterface<T> {
  protected BstNode<T> root;

  public boolean isEmpty() {
    return root == null;
  }

  public int size() {
    return subtreeSize(root);
  }

  protected int subtreeSize(BstNode<T> node) {
    if (node == null) {
      return 0;
    } else {
      return 1 + subtreeSize(node.getLeft()) + subtreeSize(node.getRight());
    }
  }

  /** contains method.
   *  @param t : target element
   */
  public boolean contains(T t) {
    if (t == null) {
      throw new NullPointerException();
    }
    return get(t) != null;
  }

  /** remove target t.
   *  @param t : target element
   */
  public boolean remove(T t) {
    if (t == null) {
      throw new NullPointerException();
    }
    boolean result = contains(t);
    if (result) {
      root = removeFromSubtree(root, t);
    }
    return result;
  }

  private BstNode<T> removeFromSubtree(BstNode<T> node, T t) {
    // node must not be null
    int result = t.compareTo(node.getData());
    if (result < 0) {
      node.setLeft(removeFromSubtree(node.getLeft(), t));
      if (node.getLeft() != null) { 
        node.getLeft().setParent(node);
      }
      return node;
    } else if (result > 0) {
      node.setRight(removeFromSubtree(node.getRight(), t));
      if (node.getRight() != null) {
        node.getRight().setParent(node);
      }
      return node;
    } else { // result == 0
      if (node.getLeft() == null) {
        return node.getRight();
      } else if (node.getRight() == null) {
        return node.getLeft();
      } else { // neither child is null
        T predecessorValue = getHighestValue(node.getLeft());
        node.setLeft(removeRightmost(node.getLeft()));
        if (node.getLeft() != null) { 
          node.getLeft().setParent(node);
        }
        node.setData(predecessorValue);
        return node;
      }
    }
  }

  private T getHighestValue(BstNode<T> node) {
    // node must not be null
    if (node.getRight() == null) {
      return node.getData();
    } else {
      return getHighestValue(node.getRight());
    }
  }

  private BstNode<T> removeRightmost(BstNode<T> node) {
    // node must not be null
    if (node.getRight() == null) {
      return node.getLeft();
    } else {
      node.setRight(removeRightmost(node.getRight()));
      if (node.getRight() != null) {
        node.getRight().setParent(node);
      }
      return node;
    }
  }

  /** get node contains target t.
   *  @param t : target element
   */
  public T get(T t) {
    if (t == null) {
      throw new NullPointerException();
    }
    Queue<T> queue = new LinkedList<T>();
    inorderTraverse(queue, root);
    for (T i : queue) {
      if (i.equals(t)) {
        return i;
      }
    }
    return null;
  }


  /** add t into the tree.
   *  @param t : new element
   */
  public void add(T t) {
    if (t == null) {
      throw new NullPointerException();
    }
    root = addToSubtree(root, new BstNode<T>(t, null, null));
  }

  protected BstNode<T> addToSubtree(BstNode<T> node, BstNode<T> toAdd) {
    if (node == null) {
      return toAdd;
    }
    int result = toAdd.getData().compareTo(node.getData());
    if (result <= 0) {
      node.setLeft(addToSubtree(node.getLeft(), toAdd));
      if (node.getLeft() != null) { 
        node.getLeft().setParent(node);
      }
    } else {
      node.setRight(addToSubtree(node.getRight(), toAdd));
      if (node.getRight() != null) {
        node.getRight().setParent(node);
      }
    }
    return node;
  }

  @Override
  public T getMinimum() {
    if (root == null) {
      return null;
    }
    BstNode<T> temp = root;
    while (temp.getLeft() != null) {
      temp = temp.getLeft();
    }
    return temp.getData();
  }


  @Override
  public T getMaximum() {
    if (root == null) {
      return null;
    }
    BstNode<T> temp = root;
    while (temp.getRight() != null) {
      temp = temp.getRight();
    }
    return temp.getData();
  }


  @Override
  public int height() {
    return height(root);
  }
  
  
  /**
   * Recursive helper method for height().
   * @param node root of BST
   * @return
   */
  public int height(BstNode<T> node) {
    if (node == null) {
      return -1;
    }
    int leftHeight = height(node.getLeft());
    int rightHeight = height(node.getRight());
    if (leftHeight > rightHeight) {
      return leftHeight + 1;
    }
    return rightHeight + 1;
  }
  

  /** pre-order traversal iterator.
   *  
   */
  public Iterator<T> preorderIterator() {
    Queue<T> queue = new LinkedList<T>();
    preorderTraverse(queue, root);
    return queue.iterator();
  }

  
  private void preorderTraverse(Queue<T> queue, BstNode<T> node) {
    if (node != null) {
      queue.add(node.getData());
      preorderTraverse(queue, node.getLeft());
      preorderTraverse(queue, node.getRight());
    }
  }


  /** in-order traversal iterator.
   *  
   */
  public Iterator<T> inorderIterator() {
    Queue<T> queue = new LinkedList<T>();
    inorderTraverse(queue, root);
    return queue.iterator();
  }


  private void inorderTraverse(Queue<T> queue, BstNode<T> node) {
    if (node != null) {
      inorderTraverse(queue, node.getLeft());
      queue.add(node.getData());
      inorderTraverse(queue, node.getRight());
    }
  }

  /** post-order traversal iterator.
   *  
   */
  public Iterator<T> postorderIterator() {
    Queue<T> queue = new LinkedList<T>();
    postorderTraverse(queue, root);
    return queue.iterator();
  }


  private void postorderTraverse(Queue<T> queue, BstNode<T> node) {
    if (node != null) {
      postorderTraverse(queue, node.getLeft());
      postorderTraverse(queue, node.getRight());
      queue.add(node.getData());
    }
  }


  @Override
  public boolean equals(BstInterface<T> other) {
    if (other == null) {
      throw new NullPointerException();
    }
    return equals(this.root, other.getRoot());
  }
  
  /**
   * Recursive helper method of equals().
   * @param nodeA root of first BST in comparison.
   * @param nodeB root of second BST in comparison.
   * @return true iff both BST have the same structure and values
   */
  private boolean equals(BstNode<T> nodeA, BstNode<T> nodeB) {
    if (nodeA == null || nodeB == null) {
      return nodeA == null && nodeB == null;
    }    
    boolean leftEqual = equals(nodeA.getLeft(), nodeB.getLeft()); 
    boolean rightEqual = equals(nodeA.getRight(), nodeB.getRight());
    return leftEqual && rightEqual && nodeA.getData().equals(nodeB.getData());
  }


  @Override
  public boolean sameValues(BstInterface<T> other) {
    if (other == null) {
      throw new NullPointerException();
    }
    Iterator<T> thisBst = this.inorderIterator();
    Iterator<T> otherBst = other.inorderIterator();
    
    while (thisBst.hasNext() && otherBst.hasNext()) {
      if (!thisBst.next().equals(otherBst.next())) {
        return false;
      }
    }
    return !(thisBst.hasNext() || otherBst.hasNext());
  }

  @Override
  public boolean isBalanced() {
    if (size() <= 1) {
      return true;
    }
    int n = size();
    int h = height();
    return Math.pow(2, h) <= n && n < Math.pow(2, h + 1);
  }
  

  @Override
  @SuppressWarnings("unchecked")

  public void balance() {
    Iterator<T> sortedIter = inorderIterator();
    int s = size();
    T[] sortedArr = (T[]) new Comparable[s];
    int i = 0;
    while (sortedIter.hasNext()) {
      sortedArr[i] = sortedIter.next();
      i++;
    }
    root = arr2Bst(0, s - 1, sortedArr);
  }
  
  private BstNode<T> arr2Bst(int lower, int upper, T[] arr) {
    if (lower > upper) {
      return null;
    }
    int mid = (lower + upper) / 2;
    BstNode<T> node = new BstNode<T>(arr[mid], null, null);
    node.setLeft(arr2Bst(lower, mid - 1, arr));
    node.setRight(arr2Bst(mid + 1, upper, arr));    
    
    return node;
  }


  @Override
  public BstNode<T> getRoot() {
    // DO NOT MODIFY
    return root;
  }

  /** helper method for formatting.
   * 
   * @param root : root of tree.
   */
  public static <T extends Comparable<T>> String toDotFormat(BstNode<T> root) {
    // header
    int count = 0;
    String dot = "digraph G { \n";
    dot += "graph [ordering=\"out\"]; \n";
    // iterative traversal
    Queue<BstNode<T>> queue = new LinkedList<BstNode<T>>();
    queue.add(root);
    BstNode<T> cursor;
    while (!queue.isEmpty()) {
      cursor = queue.remove();
      if (cursor.getLeft() != null) {
        // add edge from cursor to left child
        dot += cursor.getData().toString() + " -> "
            + cursor.getLeft().getData().toString() + ";\n";
        queue.add(cursor.getLeft());
      } else {
        // add dummy node
        dot += "node" + count + " [shape=point];\n";
        dot += cursor.getData().toString() + " -> " + "node" + count
            + ";\n";
        count++;
      }
      if (cursor.getRight() != null) {
        // add edge from cursor to right child
        dot += cursor.getData().toString() + " -> "
            + cursor.getRight().getData().toString() + ";\n";
        queue.add(cursor.getRight());
      } else {
        // add dummy node
        dot += "node" + count + " [shape=point];\n";
        dot += cursor.getData().toString() + " -> " + "node" + count
            + ";\n";
        count++;
      }

    }
    dot += "};";
    return dot;
  }

  /** supporting main function.
   * 
   */
  public static void main(String[] args) {
    for (String r : new String[] { "a", "b", "c", "d", "e", "f", "g" }) {
      BstInterface<String> tree = new BinarySearchTree<String>();
      for (String s : new String[] { "d", "b", "a", "c", "f", "e", "g" }) {
        tree.add(s);
      }
      Iterator<String> iterator = tree.inorderIterator();
      while (iterator.hasNext()) {
        System.out.print(iterator.next());
      }
      System.out.println();
      iterator = tree.preorderIterator();
      while (iterator.hasNext()) {
        System.out.print(iterator.next());
      }
      System.out.println();
      iterator = tree.postorderIterator();
      while (iterator.hasNext()) {
        System.out.print(iterator.next());
      }
      System.out.println();

      System.out.println(tree.remove(r));

      iterator = tree.inorderIterator();
      while (iterator.hasNext()) {
        System.out.print(iterator.next());
      }
      System.out.println();
    }

    BstInterface<String> tree = new BinarySearchTree<String>();
    for (String r : new String[] { "a", "b", "c", "d", "e", "f", "g" }) {
      tree.add(r);
    }
    System.out.println(tree.size());
    System.out.println(tree.height());
    System.out.println(tree.isBalanced());
    tree.balance();
    System.out.println(tree.size());
    System.out.println(tree.height());
    System.out.println(tree.isBalanced());
  }
}