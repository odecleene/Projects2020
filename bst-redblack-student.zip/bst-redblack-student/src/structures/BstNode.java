package structures;

/**
 * A node in a BST.
 * Note that BSTNode MUST implement BSTNodeInterface; removing this will result
 * in your program failing to compile for the autograder.
 * 
 * @author liberato
 *
 * @param <T> : generic type.
 */
public class BstNode<T extends Comparable<T>> implements BstNodeInterface<T> {
  private T data;
  private BstNode<T> left;
  private BstNode<T> right;
  private BstNode<T> parent;

  public static final boolean RED   = true;
  public static final boolean BLACK = false;
  private boolean color;

  /** constructor.
   * 
   * @param data : data
   * @param left : left subtree
   * @param right : right subtree
   */
  public BstNode(T data, BstNode<T> left, BstNode<T> right) {
    this.data = data;
    this.left = left;
    this.right = right;
    parent = null;
  }

  /** constructor.
   * 
   * @param data : data
   * @param left : left subtree
   * @param right : right subtree
   */
  public BstNode(T data, BstNode<T> left, BstNode<T> right, boolean color) {
    this.data = data;
    this.left = left;
    this.right = right;
    this.color = color;
    parent = null;
  }

  public T getData() {
    return data;
  }

  public void setData(T data) {
    this.data = data;
  }

  public boolean getColor() {
    return color;
  }

  public void setColor(boolean color) {
    this.color = color;
  }

  public BstNode<T> getLeft() {
    return left;
  }

  public void setLeft(BstNode<T> left) {
    this.left = left;
  }

  public BstNode<T> getRight() {
    return right;
  }

  public void setRight(BstNode<T> right) {
    this.right = right;
  }

  public BstNode<T> getParent() {
    return parent;
  }

  public void setParent(BstNode<T> p) {
    this.parent = p;
  }
  
  /** gets grandparent node, or parent of parent.
   * 
   * @return grandparent node of this node, returns null if nonexistent
   */
  public BstNode<T> getGrandparent() {
    if (parent == null) {
      return null;
    }
    return parent.getParent();
  }
  
  /** gets uncle node, or sibling of parent node.
   * 
   * @return uncle node of this node returns null if no such node exists
   */
  public BstNode<T> getUncle() {
    BstNode<T> gparent = getGrandparent();
    if (gparent == null) {
      return null;
    }
    if (gparent.getLeft() == parent) {
      return gparent.getRight();
    }
    return gparent.getLeft();
  }
  
  /** indicates if node is inside or outside node.
   * 
   * @return true if node is an "outside node", false if node is an "inside node"
   */
  public boolean isOutside() {
    BstNode<T> gpa = getGrandparent();
    if (gpa == null) {
      return true;
    }
    if (gpa.getLeft() == null) {
      return getParent().getRight() == this;
    }
    if (gpa.getRight() == null) {
      return getParent().getLeft() == this;
    }
    boolean testLeft = this.equals(gpa.getLeft().getLeft());
    boolean testRight = this.equals(gpa.getRight().getRight());
    
    return testLeft || testRight;
  }

  /** print sub-tree.
   * 
   * @param spaces : formatting space
   */
  public void printSubtree(int spaces) {
    if (right != null) {
      right.printSubtree(spaces + 5);
    }
    for (int i = 0; i < spaces; i++) {
      System.out.print(" ");
    }
    System.out.print(data);
    System.out.print('-');
    System.out.println(color);
    if (left != null) {
      left.printSubtree(spaces + 5);
    }
  }
}