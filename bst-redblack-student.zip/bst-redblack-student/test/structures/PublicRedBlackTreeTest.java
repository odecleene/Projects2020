package structures;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

public class PublicRedBlackTreeTest {

  private RedBlackTree<Integer> tree1, tree2;

  //@Rule
  //public Timeout timeout = new Timeout(1L, TimeUnit.SECONDS);

  @Before
  public void before() {
    tree1 = new RedBlackTree<Integer>();
    tree2 = new RedBlackTree<Integer>();
  }
  
  @Test
  public void testAdd2() {
    int[] num = {1, 2, 3, 4, 5, 6, 7, 8};
    for (int n : num) {
      tree1.add(n);
    }
    assertTrue(tree1.isBalanced());
  }
  
  
  
  
/*
  @Test
  public void testAdd() {
    tree1.add(0);
    tree2.add(0);
    tree2.balance();
    tree2.printTree();
    tree1.printTree();
    assertTrue(tree1.getRoot().getColor() == BstNode.BLACK);
    assertEquals(1, tree1.size());
    assertEquals(0, tree1.height());
    tree1.add(1);
    tree2.add(1);
    tree2.balance();
    tree2.printTree();
    tree1.printTree();
    assertTrue(tree1.getRoot().getColor() == BstNode.BLACK);
    assertEquals(2, tree1.size());
    assertEquals(1, tree1.height());
    tree1.add(2);
    tree2.add(2);
    tree2.balance();
    tree2.printTree();
    tree1.printTree();
    assertTrue(tree1.getRoot().getColor() == BstNode.BLACK);
    assertEquals(3, tree1.size());
    assertEquals(1, tree1.height());
    tree1.add(3);
    tree2.add(3);
    tree2.balance();
    tree2.printTree();
    tree1.printTree();
    assertTrue(tree1.getRoot().getColor() == BstNode.BLACK);
    assertEquals(4, tree1.size());
    assertEquals(2, tree1.height());
    tree1.add(4);
    tree2.add(4);
    tree2.balance();
    tree2.printTree();
    tree1.printTree();
    assertTrue(tree1.getRoot().getColor() == BstNode.BLACK);
    assertEquals(5, tree1.size());
    assertEquals(2, tree1.height());
    tree1.add(5);
    tree2.add(5);
    tree2.balance();
    tree2.printTree();
    tree1.printTree();
    assertTrue(tree1.getRoot().getColor() == BstNode.BLACK);
    assertEquals(6, tree1.size());
    assertEquals(2, tree1.height());

    tree2.add(0);
    tree2.add(1);
    tree2.add(2);
    tree2.add(3);
    tree2.add(4);
    tree2.balance();
    tree2.printTree();
  }
*/
}
